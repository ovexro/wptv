<div id="cookie-consent-banner" class="cookie-consent-banner">
    <div class="cookie-consent-content">
        <p class="cookie-consent-text">
            This website uses cookies to enhance your experience and for site analytics. By continuing to use this site, you agree to our use of cookies.
        </p>
        <button id="cookie-consent-accept" class="cookie-consent-button">Got it!</button>
    </div>
</div>
